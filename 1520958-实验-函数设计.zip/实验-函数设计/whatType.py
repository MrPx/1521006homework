strCount=0
intCount = 0
spaceCount=0
otherCount = 0
list1=[]
list2=[]
list3=[]
list4=[]
a = input(" input a string:")
for i in a:   
    if i.isdigit(): 
        intCount += 1
        list1.append(i)
    elif i.isalpha(): 
        strCount += 1
        list2.append(i)
    elif i.isspace():
        spaceCount +=1
        list3.append(i)
    else:
        otherCount += 1
        list4.append(i)
print ('英文=%d个,分别是')
print (list1)
print ('数字=%d个,分别是'%intCount)
print (list2)
print ('空格=%d个,分别是'%spaceCount)
print (list3)
print ('其他=%d个分别是'%otherCount)
print (list4)
