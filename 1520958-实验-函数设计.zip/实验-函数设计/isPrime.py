import string
def isPrime(n):
  if(n<2):
    return False;
  elif(n==2):
    return True;
  elif(n>2):
    for d in range(2,n-1):
      if(n%d==0):
        return False;
  return True;

