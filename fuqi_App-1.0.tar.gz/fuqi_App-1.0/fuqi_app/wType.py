strCount=0
intCount = 0
spaceCount=0
otherCount = 0
a = input(" input a string:")
for i in a:   
    if i.isdigit(): 
        intCount += 1
    elif i.isalpha(): 
        strCount += 1
    elif i=='':
        spaceCount +=1
    else:
        otherCount += 1
print ("英文="%d%strCount)
print ("数字="%d，%intCount)
print ("空格="%d，%spaceCount)
print ("其他="%d，%otherCount)
