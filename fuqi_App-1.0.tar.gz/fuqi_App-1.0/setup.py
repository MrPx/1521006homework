#coding:utf8
from setuptools import setup
 
setup(
    name='fuqi_App',         # 应用名
    version='1.0',        # 版本号
    packages=['fuqi_app']    # 包括在安装包内的Python包
)
